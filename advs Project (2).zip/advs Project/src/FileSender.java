import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class FileSender{
	private DatagramSocket udpServerSocket;
	private DatagramPacket udpPacket;
	private String sender_path;
	private String Requested_file;

public FileSender() {}
public FileSender(DatagramSocket socket,DatagramPacket udpReceiverPacket,String path,String file) {
	this.udpServerSocket=socket;
	this.udpPacket = udpReceiverPacket;
	this.sender_path = path;
	this.Requested_file=file;
}
public void run() {
	try {		
		BufferMonitor bufferMonitor=new BufferMonitor(3);
		PacketSender packetSender=new PacketSender(bufferMonitor,udpServerSocket,udpPacket);
		packetSender.start();
		
		FileReader fileReader=new FileReader(bufferMonitor,sender_path,Requested_file);
		fileReader.start();
		
		try {
			packetSender.join();
			fileReader.join();				
		} 
 		catch (InterruptedException e) {}
		
	}catch(Exception e) {e.printStackTrace();}
	
}
	}