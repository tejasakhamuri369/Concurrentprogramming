import java.net.DatagramPacket;
import java.net.DatagramSocket;


public class PacketSender extends TDThread {
	private BufferMonitor bufferMonitor;	
	private DatagramSocket udpSenderSocket;
	private DatagramPacket udpSenderPacket;

	
	public PacketSender() {}
	public PacketSender(BufferMonitor bm, DatagramSocket socket,DatagramPacket udpSenderPacket) {
		this.bufferMonitor=bm;
		this.udpSenderSocket=socket;
		this.udpSenderPacket=udpSenderPacket;			
	}
	
	public void run() {
		byte[] buf=new byte[Constants.MAX_DATAGRAM_SIZE];
		byte []receiveBuf=new byte[1024];
		try {			
			
			System.out.println(">> Begin to send packets"+Constants.CRLF);
			while(true) {
				//withdraw an item 
				Packet pktS=this.bufferMonitor.withdraw();
				buf=new byte[Constants.MAX_DATAGRAM_SIZE];
				buf=pktS.packetToByteArray();
				udpSenderPacket.setData(buf,0,pktS.getContentSize()+4);
				udpSenderSocket.send(udpSenderPacket);
				
				System.out.println(">> Send the packet with index "+pktS.getIndex());
				
				// get an ACK packet				
				while(true){
					try {
						udpSenderSocket.setSoTimeout(100);
						udpSenderPacket.setData(receiveBuf,0,receiveBuf.length);
						udpSenderSocket.receive(udpSenderPacket);
					}catch(Exception e) {
						System.out.println(">> Resend the packet with index "+pktS.getIndex()+Constants.CRLF);
						udpSenderPacket.setData(buf,0,pktS.getContentSize()+4);
						udpSenderSocket.send(udpSenderPacket);
					}
					int index=Helper.byteArrayToInt(Helper.get4Bytes(udpSenderPacket.getData()));
					if (index==pktS.getIndex()) {
						System.out.println("ACK for the packet with index "+index+Constants.CRLF);			
						break;
					}								
				}
				
				if (pktS.getIndex()==-1) {
					System.out.println(">> Finish sending packets.");
					break;
				}				
			}
		}catch(Exception e) {e.printStackTrace();}
		
	}

}
