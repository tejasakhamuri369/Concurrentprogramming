
final class BufferMonitor extends monitorSC {
	private int fullSlots = 0; 			// # of full slots in the buffer
	private int capacity = 0;
	private Packet[] buffer=null;
   //private int[] buffer = null;
   private int in = 0, out = 0;

	private conditionVariable notFull;
	private conditionVariable notEmpty;

	public BufferMonitor(int capacity) {
		super("Buffer");
		this.capacity = capacity;
		buffer = new Packet[capacity];
		notFull = new conditionVariable("notFull");
		notEmpty = new conditionVariable("notEmpty");
	}

	public void deposit(Packet pkt) {
		enterMonitor("deposit");
		while (fullSlots == capacity)  {
			notFull.waitC();
		}
		buffer[in] = pkt;
      in = (in + 1) % capacity;
		++fullSlots;
		//System.out.println(">> deposit the packet index: "+pkt.getIndex());
		exerciseEvent("deposit");
		notEmpty.signalCall();
		exitMonitor();
}

	public Packet withdraw() {
		enterMonitor("withdraw");
		Packet pkt;
		while (fullSlots == 0) {
			notEmpty.waitC();
		}
		pkt = buffer[out];
      out = (out + 1) % capacity;
		--fullSlots;
		exerciseEvent("withdraw");
		notFull.signalCall();
		//System.out.println(">> withdraw the packet index: "+pkt.getIndex());
		
		exitMonitor();
		return pkt;
	}
}






