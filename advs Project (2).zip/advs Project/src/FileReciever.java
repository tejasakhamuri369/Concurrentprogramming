import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class FileReciever{
	private DatagramSocket udpServerSocket;
	private DatagramPacket udpPacket;
	private String reciever_path;
	
	public FileReciever() {}
	public FileReciever(DatagramSocket socket,DatagramPacket udpReceiverPacket,String path) {
		this.udpServerSocket=socket;
		this.udpPacket = udpReceiverPacket;
		this.reciever_path = path;
	}
	public void run() {
		try {		
			BufferMonitor bm=new BufferMonitor(Constants.MONITOR_BUFFER_SIZE);
    		
    		PacketReceiver packetReceiver=new PacketReceiver(bm,udpServerSocket,udpPacket);
    		packetReceiver.start();
    		
    		FileWriter fileWriter=new FileWriter(bm,reciever_path);
    		fileWriter.start();	
    		try {
    			packetReceiver.join();
    			fileWriter.join();
    		} 
    			catch (InterruptedException e) {e.printStackTrace();}
			
		}catch(Exception e) {e.printStackTrace();}
		
	}
}
