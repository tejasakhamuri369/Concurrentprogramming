import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Server{
	public static void main(String[] args) throws IOException 
    {
        // Starting server
		@SuppressWarnings("resource")
		ServerSocket serverSocket=new ServerSocket(Constants.SERVER_TCP_PORT);
		// Ready to accept connection requests from clients
		System.out.println("\r\n>> Ready to accept requests");
		//getting ip address of local server
		InetAddress serverIp=InetAddress.getByName("localhost");
		// Initialization of Datagram socket for udp transfer 
		DatagramSocket udpServerSocket =new DatagramSocket(Constants.SERVER_UDP_PORT, serverIp);

        // running loop for getting
        // client request
        while (true) 
        {            
            try {// Wait for clients...
    			
            	Socket client = serverSocket.accept();				
            	System.out.println("\n>> New request is accepted."+Constants.CRLF);
				Thread th = new ClientHandler(client,udpServerSocket);
	            // Invoking the start() method for client handler
				
	            th.start();
	            }
	        catch (Exception e){
	 				System.out.println("\n>> Unable to set up port!");
	 				e.printStackTrace();
	 				System.exit(1);
	        }
        }
        }
}

class ClientHandler extends Thread 
{
    Socket client;
    DatagramSocket udpServerSocket;
      
  
    // Constructor
    public ClientHandler(Socket s,DatagramSocket udpServerSocket) 
    {
        client = s;
        this.udpServerSocket=udpServerSocket;
    }
  
	public void run() {
	try {
		//Data stream for TCP communication
		DataInputStream datain = new DataInputStream(client.getInputStream());
		DataOutputStream dataout = new DataOutputStream(client.getOutputStream());
		
		// Reading request from clients
		int Client_port = datain.readInt();
		System.out.print("Connected to Client on port :"+Client_port+Constants.CRLF);
		byte[] buf=new byte[Constants.MAX_DATAGRAM_SIZE];
		InetAddress serverIp=InetAddress.getByName("localhost");
		DatagramPacket udpPacket;
		
		try {
			udpPacket=new DatagramPacket(buf,Constants.MAX_DATAGRAM_SIZE,serverIp,Client_port);
		}catch(Exception e) {
			System.out.println(Constants.CRLF+">> Fail to reach the server."+Constants.CRLF);
			e.printStackTrace();
			return;
		}
		// handle multiple client connections
		while(true){
			try {				
				// get action type from the received data
				while(true) {
				String line=datain.readUTF();	
			    	if(line.contains("DOWNLOAD")){		    		
			    		String Requested_file=line.split("#")[1].strip();
			    		//sending file to client
			    		FileSender sender= new FileSender(udpServerSocket,udpPacket,Constants.SERVER_FILE_ROOT,Requested_file);
						sender.run();
			    	}
			    	else if(line.contains("UPLOAD")) {
			    		//receiving file from client
			    		FileReciever receiver= new FileReciever(udpServerSocket,udpPacket,Constants.SERVER_FILE_ROOT);
			    		receiver.run();
			    	}
					else if(line.contains("FILES LIST")) {
						File folder = new File(Constants.SERVER_FILE_ROOT);
						String li;
						try {
						String listOfFiles_server[] = folder.list();
						li = String.join("@", listOfFiles_server);}
						catch (Exception e) {li="EMPTY";}
						//sending list of files present in server to client.
						dataout.writeUTF(li);
					}
			    
					else if (line.contains("DELETE FILE")) {
					String Delete_file = line.split("#")[1].strip();
					File Obj = new File(Constants.SERVER_FILE_ROOT+Delete_file); 
					//File delete
				    if (Obj.delete()) {
				    	System.out.println(">>Succesfully deleted the file:"+Delete_file+Constants.CRLF);
				    }
				    else {
				        System.out.println(">>Failed to delete the file:"+Delete_file+Constants.CRLF);
				      }
			    	
			    }
				}
			}catch(IOException io) {
				System.out.println(">> Fail to listen to requests!");
				System.exit(1);
			}
			
			
		}// end of while loop

	}catch(Exception e) {
		e.printStackTrace();
	}
}
}