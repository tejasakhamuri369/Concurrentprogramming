import java.net.DatagramPacket;
import java.net.SocketTimeoutException;
import java.net.DatagramSocket;

public class PacketReceiver extends TDThread {
	private BufferMonitor bufferMonitor;	
	private DatagramSocket udpReceiverSocket;
	private DatagramPacket udpReceiverPacket;
	public boolean completed = false;
	
	public PacketReceiver() {}
	public PacketReceiver(BufferMonitor bm,DatagramSocket socket,DatagramPacket udpReceiverPacket) {
		this.bufferMonitor=bm;
		this.udpReceiverSocket=socket;
		this.udpReceiverPacket = udpReceiverPacket;
	}
	
	public void run() {
		try {		
			byte[] buf=new byte[Constants.MAX_DATAGRAM_SIZE];	
			//udpReceiverPacket=new DatagramPacket(buf,Constants.MAX_DATAGRAM_SIZE,senderIp,senderPort);
			int expectPacketIndex=0;
			int currentPacketIndex=0;
			
			System.out.println(">> Begin to receive packets"+Constants.CRLF);
			while(true) {				
				//receive packets
				buf=new byte[Constants.MAX_DATAGRAM_SIZE];
				try {
				udpReceiverPacket.setData(buf,0,buf.length);
				udpReceiverSocket.receive(udpReceiverPacket);}
				catch (SocketTimeoutException ex) {
				}
								
				Packet pkt=new Packet(udpReceiverPacket.getData(),udpReceiverPacket.getLength());													
				System.out.println(">> Receive the packet with index "+pkt.getIndex());
				
				// send an ACK packet in case that the packet has already received.
				currentPacketIndex=pkt.getIndex();
				if (currentPacketIndex!=-1) {
					while(currentPacketIndex<expectPacketIndex) {
						// send an ACK with the packet index received
						udpReceiverPacket.setData(Helper.intToByteArray(currentPacketIndex),0,4);				
						udpReceiverSocket.send(udpReceiverPacket);
						
						buf=new byte[Constants.MAX_DATAGRAM_SIZE];
						udpReceiverSocket.receive(udpReceiverPacket);									
						pkt=new Packet(udpReceiverPacket.getData(),udpReceiverPacket.getLength());
						currentPacketIndex=pkt.getIndex();
						System.out.println("   Send an ACK packet for packet "+currentPacketIndex+Constants.CRLF);
					}
				}
				
				// send an ACK with the packet index received
				udpReceiverPacket.setData(Helper.intToByteArray(currentPacketIndex),0,4);				
				udpReceiverSocket.send(udpReceiverPacket);
				System.out.println("   Send an ACK packet for packet "+currentPacketIndex+Constants.CRLF);
							         
				//deposit
				this.bufferMonitor.deposit(pkt);
				// increase expectPacketIndex
				expectPacketIndex+=1;
				
				if (pkt.getIndex()==-1) {
					System.out.println(">> Finish receiving packets");
					this.completed = true;
					break;
				}				
				
			}//end of receiving a file		
		}catch(Exception e) {e.printStackTrace();
		}
	}
}
