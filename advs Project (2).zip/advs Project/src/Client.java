import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.io.*;



public class Client extends Thread{
	private int serverTCP;
	private int serverUDP;
	private int clientUDP;
	private String clientpath;
	
	public Client(int sTCP,int sUDP,int cUDP,String cpath) {
		serverTCP = sTCP;
		serverUDP = sUDP;
		clientUDP = cUDP;
		clientpath = cpath;
	}

	public static void main(String[] args) throws InterruptedException, IOException {
		
		Client thread = new Client(Constants.SERVER_TCP_PORT,Constants.SERVER_UDP_PORT,Constants.CLIENT_UDP_PORT,Constants.CLIENT_FILE_ROOT);
		//running the client
		thread.start();
		
	}// end of main
	
	@SuppressWarnings("resource")
	public void run() {
			byte[] buf=new byte[Constants.MAX_DATAGRAM_SIZE];
			List<String> files_list = new ArrayList<>();
			try {
			InetAddress serverIp=InetAddress.getByName("localhost");			
			Socket tcpSocket = new Socket(serverIp, serverTCP);
			DataInputStream datain = new DataInputStream(tcpSocket.getInputStream());
			DataOutputStream dataout = new DataOutputStream(tcpSocket.getOutputStream());
			dataout.writeInt(clientUDP);
			DatagramSocket udpClientSocket;
			DatagramPacket udpPacket;
			try {
				udpClientSocket=new DatagramSocket(clientUDP, serverIp);	
				udpPacket=new DatagramPacket(buf,Constants.MAX_DATAGRAM_SIZE,serverIp,serverUDP);
			}catch(Exception e) {
				System.out.println(Constants.CRLF+">> Fail to reach the server."+Constants.CRLF);
				return;
			}
			
			while(true){
			String request="FILES LIST"+" # "+clientUDP;
			dataout.writeUTF(request+Constants.CRLF);
			String server_list=datain.readUTF();
			String[] listOfFile_server =server_list.split("@");
			
			File folder = new File(clientpath);
			String[] listOfFiles_client = folder.list();
			if(listOfFiles_client==null) {
				continue;
			}

			for(String name :listOfFiles_client){
				
				if(!files_list.contains(name)&&(listOfFile_server.equals("EMPTY")||!server_list.contains(name))) {
					request="UPLOAD"+" # "+name+" # "+clientUDP;
					files_list.add(name);
					dataout.writeUTF(request+Constants.CRLF);
					
					//Sending file to server
					FileSender sender= new FileSender(udpClientSocket,udpPacket,clientpath,name);
					sender.run();
				}
			}
			for(String name :listOfFile_server) {
				File server_file = new File(clientpath+name);
				boolean exists = server_file.exists();
				if(!exists) {
					if(!files_list.contains(name)&&!name.equalsIgnoreCase("EMPTY")) {
					files_list.add(name);
					request="DOWNLOAD"+" # "+name+" # "+clientUDP;
					dataout.writeUTF(request+Constants.CRLF);
					FileReciever reciever= new FileReciever(udpClientSocket,udpPacket,clientpath);
		    		reciever.run();
				}
					else {
						request="DELETE FILE"+" # "+name+" # ";
						files_list.remove(name);
						dataout.writeUTF(request+Constants.CRLF);
					}
					}
			}
			File folder1 = new File(clientpath);
			File[] listOfFiles_sync = folder1.listFiles();
			for(File file :listOfFiles_sync){
				long t1 = file.lastModified();
				File server_file = new File(Constants.SERVER_FILE_ROOT+file.getName());

				if(server_file.exists()){
				long t2 = server_file.lastModified();
				if(t1>t2){
					try{
					System.out.print(">>"+file.getName()+" Has been updated and send to server"+Constants.CRLF);
					request="UPLOAD"+" # "+file.getName()+" # "+clientUDP;
					dataout.writeUTF(request+Constants.CRLF);
					
					//Sending file to server
					FileSender sender= new FileSender(udpClientSocket,udpPacket,clientpath,file.getName());
					sender.run();
					}
					catch (Exception ex)
					{
						System.out.println(ex);
					}}
				else if(t1<t2) {
					try{
						System.out.print(">>"+file.getName()+" Has been updated and receiving from server"+Constants.CRLF);
						request="DOWNLOAD"+" # "+file.getName()+" # "+clientUDP;
						
						//Receiving updated file from server 
						dataout.writeUTF(request+Constants.CRLF);
						FileReciever reciever= new FileReciever(udpClientSocket,udpPacket,clientpath);
			    		reciever.run();
						}
						catch (Exception ex)
						{
							System.out.println(ex);
						}
					
				}
				}
			}
			folder1 = new File(clientpath);
			listOfFiles_sync = folder1.listFiles();
			for(File file :listOfFiles_sync){
				File server_file = new File(Constants.SERVER_FILE_ROOT+file.getName());

				if(!server_file.exists()){
					File Obj = new File(clientpath+file.getName()); 
					//File delete
				    if (Obj.delete()) {
				    	System.out.println(">>Succesfully deleted the file:"+file.getName()+Constants.CRLF);
				    	files_list.remove(file.getName());
				    }
				    else {
				        System.out.println(">>Failed to delete the file:"+file.getName()+Constants.CRLF);
				      }
				}
				}
				//updating for every 10000 millisecon
				Thread.sleep(10000);
			}
			}
			catch (Exception ex)
			{
				ex.printStackTrace();
			}
			
	}
	
}
	 
	

