import java.io.*;



public class Client2{
	
	public static void main(String[] args) throws InterruptedException, IOException {
		
		Client thread = new Client(Constants.SERVER_TCP_PORT,Constants.SERVER_UDP_PORT,Constants.CLIENT_UDP_PORT_2,Constants.CLIENT_FILE_ROOT_2);
		//running the client
		thread.start();
		
	}// end of main
	
}
	 
	

